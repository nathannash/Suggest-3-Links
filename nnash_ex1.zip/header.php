<!DOCTYPE html>
<html>
	<head>
		<title>Recommended Links</title>
		<meta charset='utf-8'>
		<link rel="stylesheet" type="text/css" href="lib/css/style.css">
		<!--Twitter Bootstrap, no ugly html defaults - horray!-->		
		<link rel="stylesheet" type="text/css" href="lib/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="lib/css/bootstrap-responsive.css">
	</head>
	<body>